// numeral.js language configuration
// language : portuguese brazil (pt-br)
// author : Ramiro Varandas Jr : https://github.com/ramirovjr
(function(){var e={delimiters:{thousands:".",decimal:","},abbreviations:{thousand:"mil",million:"milhões"},ordinal:function(e){return"º"},currency:{symbol:"R$"}};typeof module!="undefined"&&module.exports&&(module.exports=e);typeof window!="undefined"&&this.numeral&&this.numeral.language&&this.numeral.language("pt-br",e)})();