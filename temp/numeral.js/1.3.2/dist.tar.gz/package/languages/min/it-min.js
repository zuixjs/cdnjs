// numeral.js language configuration
// language : italian Italy (it)
// author : Giacomo Trombi : http://cinquepunti.it
(function(){var e={delimiters:{thousands:".",decimal:","},abbreviations:{thousand:"mila",million:"mil"},ordinal:function(e){return"º"},currency:{symbol:"€"}};typeof module!="undefined"&&module.exports&&(module.exports=e);typeof window!="undefined"&&this.numeral&&this.numeral.language&&this.numeral.language("it",e)})();