// numeral.js language configuration
// language : portuguese (pt-pt)
// author : Diogo Resende : https://github.com/dresende
(function(){var e={delimiters:{thousands:" ",decimal:","},abbreviations:{thousand:"k",million:"m"},ordinal:function(e){return"º"},currency:{symbol:"€"}};typeof module!="undefined"&&module.exports&&(module.exports=e);typeof window!="undefined"&&this.numeral&&this.numeral.language&&this.numeral.language("pt-pt",e)})();