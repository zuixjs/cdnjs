# Creating Your Own Custom Operators



Final Result

```js

```