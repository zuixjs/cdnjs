Please have a look at the showcases on [kartograph.org](http://www.kartograph.org/showcase/) to see running demos of Kartograph.js.

The source code of all demos is [hosted on Github](https://github.com/kartograph/kartograph.org/tree/master/showcase), too.