module.exports = function(url, username, password, callback) {
  callback(null, {});
};
